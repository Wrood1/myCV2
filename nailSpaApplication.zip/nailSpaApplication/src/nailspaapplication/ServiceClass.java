
package nailspaapplication;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class ServiceClass {

    //services price 
   private double total;
   private int choice2;
   //info about customer services
   private String service;
   Scanner input = new Scanner(System.in);
   //like a flag
   private boolean run2;
   //customer note
    String note ;

   public ServiceClass()  {
       total = 0.0;
       service ="";
       run2 = true;
     
   }
     /**
        Constructor
        @param note The customer's note.
        */
   
 public ServiceClass(String note) {
       total = 0.0;
       service ="";
       run2 = true;
      this.note=note;
   }
/**
        The getTotal method
        @return services price 

        */
   public double getTotal() {
       return total;
   }


//================================================================================
   public void Manicures() throws IOException {
       
       FileWriter file = new FileWriter("service.txt",true);
       PrintWriter write1 = new PrintWriter(file);
 do {
        System.out.println("------ Manicures ------ ");

        System.out.println(" 1- Regular Manicures         $25 ");
        System.out.println(" 2- Gel Manicures             $40 ");
        System.out.println(" 3- Gel Manicures (french)    $40 ");
        System.out.println(" 4- Paraffin wax & Manicures  $35 ");
        System.out.println("(0)  Exist  ");
        choice2 = input.nextInt();
        

           switch (choice2) {
               case 1:
                   total += 25;
                  service="Regular Manicures";
                   write1.println(service );
                   break;
               case 2:
                   total += 40;
                   service = "Gel Manicures ";
                   write1.println(service );
                   break;
               case 3:
                   total += 40;
                   service = "Gel Manicures (french)";
                   write1.println(service);
                   break;
               case 4:
                   total += 35;
                   service = "Paraffin wax & Manicures";
                   write1.println(service );
                   break;
               case 0:
                   run2=false;
                   break;
               default:
                   System.out.println(" Error ");
                   break;
           }
           
        }while(run2);
      write1.close();
   }

   //==================================================================== 
   public void Pedicure() throws IOException {
       run2= true;
       
       FileWriter ser = new FileWriter("service.txt",true);
       PrintWriter write2 = new PrintWriter(ser);
       
       
       do{
       System.out.println("------ Pedicure ------ ");

       System.out.println(" 1- Spa Pedicure salt          $25 ");
       System.out.println(" 2- Spa Pedicure Treatment     $30 ");
       System.out.println(" 3- European Spa               $40 ");
       System.out.println(" 4- Gel Pedicure               $40 ");
       System.out.println(" (0) Exit");
       choice2 = input.nextInt();

       switch (choice2) {
           case 1:
               total += 25;
               service = "Spa Pedicure salt  ";
                write2.println(service );

               break;
           case 2:
               total += 30;
               service = "Spa Pedicure Treatment";
                write2.println(service );
               break;
           case 3:
               total += 40;
               service = "European Spa  ";
                write2.println(service );
               break;
           case 4:
               total += 40;
               service = "Gel Pedicure";
                write2.println(service );
               break;
           case 0:
               run2=false;
               break;
           default:
               System.out.println(" Error ");
               break;
       }
      
       }while(run2);
       write2.close();
   }

   //===============================================================   
   public void kidsServices() throws IOException {
       run2=true;
       FileWriter file = new FileWriter("service.txt",true);
       PrintWriter write3 = new PrintWriter(file);
       do{
       System.out.println("------ kids services ------ ");

       System.out.println(" 1- Regular Manicures         $13 ");
       System.out.println(" 2- Gel Manicures             $25 ");
       System.out.println(" 3- Gel Manicures (french)    $30 ");
       System.out.println(" 4- Paraffin wax & Manicures  $18 ");
       System.out.println(" (0) Exit");
       choice2 = input.nextInt();

       switch (choice2) {
           case 1:
               total += 13;
               service = "Regular Manicures ";
                write3.println(service );
               break;
           case 2:
               total += 25;
               service = "Gel Manicures";
                write3.println(service );
               break;
           case 3:
               total += 30;
               service = "Gel Manicures (french)";
                write3.println(service );
               break;
           case 4:
               total += 18;
               service = "Paraffin wax & Manicures";
                write3.println(service );
               break;
           case 0 :
               run2=false;
               break;
           default:
               System.out.println(" Error ");
                write3.println(service );
               break;
       }
       
       }while(run2);
       write3.close();
   }

   //======================================================================= 
   public void AdditionalServices() throws IOException {
       run2=true;
       FileWriter file = new FileWriter("service.txt",true);
       PrintWriter write4 = new PrintWriter(file);
       do{
       System.out.println("------ Additional services ------ ");

       System.out.println(" 1- French polish               $25 ");
       System.out.println(" 2- Nail Art (two nails)        $30 ");
       System.out.println(" 3- Nail 3D Design per each     $40 ");
       System.out.println(" 4- Salt/sugar scrub            $40 ");
       System.out.println(" 5- foot or Hand Mask           $25 ");
       System.out.println(" 6- Hands Mask with Gold-24     $30 ");
       System.out.println(" (0) Exit");
       choice2 = input.nextInt();

       switch (choice2) {
           case 1:
               total += 25;
               service = "French polish ";
               write4.println(service );
               break;
           case 2:
               total += 30;
               service = "Nail Art (two nails) ";
               write4.println(service );
               break;
           case 3:
               total += 40;
               service = "Nail 3D Design per each ";
               write4.println(service );
               
               break;
           case 4:
               total += 40;
               service = "Salt/sugar scrub  ";
               write4.println(service );
               break;
           case 5:
               total += 25;
               service = "foot or Hand Mask  ";
               write4.println(service );
               break;
           case 6:
               total += 30;
               service = "Hands Mask with Gold-24";
               write4.println(service );
               break;
           case 0:
               run2=false;
               break;
           default:
               System.out.println(" Error ");
               break;
       }
       }while(run2);
       write4.close();
   }
   public void order() throws IOException{
  
      boolean flag = false;
        Scanner sc2 = new Scanner(new FileInputStream("service.txt"));
         String line = sc2.nextLine();
          System.out.println(line);
        while (sc2.hasNextLine()) {
                   
       
               line = sc2.nextLine();//reading line by line
            
            System.out.println(line);
            flag= true;

        }
        if(flag){
        FileOutputStream writer = new FileOutputStream("service.txt");
        writer.write(("").getBytes());
        writer.close(); }
   
   }
}