
package nailspaapplication;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class BillClass {

    Scanner input = new Scanner(System.in);
//amount of donate
         public double donationAmount;
         //services price without tax and discount
    private double cost;
    private double tax;
    //like a flag
    private boolean studentdiscount;
    //amount of discount
    private  double discount;
    //services price with tax and discount
    private double finalTotal;
    
     ServiceClass Service;
 CustomerClass customer;
     private String choice;
         //services price with tax 
    private double costTax;

//=========================================================
    
      /**
        Constructor
     
        @param x Describes the customer .
        */
    public BillClass(CustomerClass x) {
        studentdiscount = false;
        tax = 0.15;
        discount = 0.30;
        costTax=0.0;
         customer =x ;
        finalTotal=0.0;
      

    }
            
        /**
        Constructor
        @param t Describes the cost .
       @param ser Describes the Service .

       */    
public BillClass(double t, ServiceClass ser) {
        studentdiscount = false;
        cost = t;
        tax = 0.15;
        discount = 0.30;
        costTax=0.0;
        // = d;
        finalTotal=0.0;
        Service = ser;

    }
    //===================================================================
    public void discount() {
        
      System.out.println("Are you student in University of Jeddah ?\n " +" y for yes ,N for no");

        choice = input.nextLine();
        switch (choice) {

            case "y":
            case "Y":
                studentdiscount = true;
                System.out.println("your are eligible for 30% discount");

                break;
            case "n":
            case "N":
                studentdiscount = false;
                break;
            default:
                System.out.println("Wrong choice");
        }

        if (studentdiscount) {
            finalTotal = ( cost - (cost * discount));

        } else if (!studentdiscount) {
            finalTotal=cost;
            System.out.println("No discount ");
        }
    }
/**
        The tax method
        @return services price with tax 

        */
    public double tax() {
        costTax += (finalTotal + (tax * finalTotal));
        return costTax;
       

    }

    public void customerprint() throws FileNotFoundException{
        for(int i=0;i<3;i++){
       System.out.print("  "+customer.TitalLine[i]+" "); 
      
        }
       System.out.println();
      System.out.println(customer.GetName()+"  "+customer.Getphone()+"  "+customer.getdate());
       System.out.println();
    
    }
    
    
    
     /**
        The toString method
        @return Information and the bill.
        */
    
    public String toString() {
String text;
 text ="_______________________________________\n"+"\n\tBill information\n "+"_______________________________________\n\n"+
" information :\t\t\t\t"+"\n"+" tax =\t\t\t\t "+tax
 +"\n"+" discount =\t\t\t  30%" +"\n" +" Total price before discount\t" + cost + "\n"
+ " Total price after discount\t "+ finalTotal + "\n" +" Total price after tax\t\t "+tax()+"\n note:"+"\n Service :\n"+Service.note;
        return text;

    }
public void donate () throws FileNotFoundException, IOException {
        String filename = "donate.txt";
          File readfile=new File(filename);
          Scanner input = new Scanner(System.in);
          double sum = 0.0;
          if(donationAmount<0){
          System.out.println("  you cannot donate by a negative number please re-enter");
          donationAmount=input.nextDouble();
          }//end of if condition 
          
        // Create a Scanner object passing File object 
        Scanner reading= new Scanner(readfile);
        // Perform a priming read to read the first line of  the file 
       String line=reading.nextLine();
       // while(reading.hasNext()){
            // Add value to sum
            sum=Double.parseDouble(line);
    
        reading.close();
        sum=sum+donationAmount;
         System.out.println("the amount of all donate is ("+sum+")");
        FileOutputStream writer = new FileOutputStream("donate.txt");
        writer.write(("").getBytes());
        writer.close();
       PrintWriter copy = new PrintWriter("donate.txt");
        copy.print(sum);
        copy.close();
    }
    }

