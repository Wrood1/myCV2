package nailspaapplication;

/**
 *
 * @author wrood,raghad
 */
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class NailSpaApplication {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) throws FileNotFoundException, IOException {

        Scanner keyboard = new Scanner(System.in);
        int choice1;
        boolean run = true;
        boolean exit = true;
        String edit;
        String note = "";
        int choice3;
        String name = "";
        String phone = "";
        CustomerClass ob1 = new CustomerClass(phone, name);
        ServiceClass ob2 = new ServiceClass();
        BillClass obbill = new BillClass(ob1);

        //-----------application loop--------------
        do {

            System.out.println("\n---WELCOME TO NAILS SPA---");
            System.out.println("\n HERE IS THE MENU:");
            System.out.println("  1.costumers\n"
                    + "  2.book an appointment\n" + "  3.donate\n"
                    + "  4.exit program");
            System.out.println("  pick one of them : ");
            choice1 = keyboard.nextInt();
            System.out.println("___________________________________________");

            switch (choice1) {

                case 1:
                    //--------coustomer-------------
                    System.out.println("     costumers \n" + " 1. add a new costumers\n"
                            + " 2. search a costumer\n" + " 3. delete costumers\n " + "4. exit");
                    choice1 = keyboard.nextInt();

                    if (choice1 == 1) {
                        //ob1.addCostumer();
                        keyboard.nextLine();
                        System.out.println("___________________________________________");

                        System.out.println("   Please enter your name");
                        name = keyboard.nextLine();
                        ob1.setName(name);
                        System.out.println("   enter your phone number");
                        phone = keyboard.nextLine();
                        ob1.setPhone(phone);
                        System.out.println("___________________________________________");
                        System.out.println("\n is your name  " + ob1.GetName()
                                + " and phone number  " + ob1.Getphone() + "?");
                        System.out.println("if yes press (Y) if no press (N)");
                        String correct = keyboard.nextLine();
                        System.out.println("___________________________________________");

                        switch (correct) {
                            case "n":
                            case "N":
                                System.out.println("___________________________________________");

                                System.out.println(" we're sorry to hear that! choose what do you whant to edit");
                                System.out.println("1.edit name");
                                System.out.println("2.edit phone");
                                System.out.println("3.edit both");
                                choice1 = keyboard.nextInt();
                                keyboard.nextLine();
                                System.out.println("___________________________________________");

                                switch (choice1) {
                                    case 1:

                                        System.out.println("enter your name:");
                                        edit = keyboard.nextLine();
                                        ob1.setName(edit);
                                        ob1.write();
                                        break;
                                    case 2:
                                        System.out.println("___________________________________________");

                                        System.out.println("enter your phone number:");
                                        edit = keyboard.nextLine();
                                        ob1.setPhone(edit);
                                        ob1.write();
                                        break;
                                    case 3:
                                        System.out.println("___________________________________________");

                                        System.out.println("enter your name:");
                                        edit = keyboard.nextLine();
                                        ob1.setName(edit);
                                        System.out.println("enter your phone number:");
                                        edit = keyboard.nextLine();
                                        ob1.setPhone(edit);
                                        ob1.write();
                                        break;
                                    default:
                                        break;
                                }//editing switch case 

                                break;
                            case "y":
                            case "Y":
                                ob1.write();
                                break;
                            default:
                        }
                    } else if (choice1 == 2) {
                        System.out.println("___________________________________________");

                        ob1.searchCostumer();

                    } else if (choice1 == 3) {
                        ob1.deleteCustomer();
                    } else if (choice1 == 0) {
                        run = false;
                    }
                    break;
                case 2:
                    //------------Service--------------------
                    System.out.println("**PLEASE NOTE THAT YOU SHOULD SIGN YOUR INFORMATION BEFORE BOOKING.**");
                    do {
                        System.out.println("choose number of the servic what do you want to show");
                        System.out.println("(1) Manicures ");
                        System.out.println("(2) Pedicure  ");
                        System.out.println("(3) kids services ");
                        System.out.println("(4) Additional services  ");
                        System.out.println("(0)  Exist  ");
                        Scanner input = new Scanner(System.in);
                        int choice;
                        choice = input.nextInt();

                        switch (choice) {
                            case 1:
                                ob2.Manicures();
                                System.out.println("___________________________________________");

                                break;
                            case 2:
                                ob2.Pedicure();
                                System.out.println("___________________________________________");

                                break;
                            case 3:
                                ob2.kidsServices();
                                System.out.println("___________________________________________");

                                break;
                            case 4:
                                ob2.AdditionalServices();
                                System.out.println("___________________________________________");

                                break;
                            case 0:
                                System.out.println("___________________________________________");

                                exit = false;
                                break;
                            default:
                                System.out.println("wrong enter");
                                break;

                        }//swich manacure
                    } while (exit);
                    
                    if (!exit) {

                        System.out.println("Would you like to add a note for your service?" + "\n1.yes\n2.no");
                        int Choice = keyboard.nextInt();
                        switch (Choice) {
                            case 1:
                                System.out.println("enter your note:");
                                keyboard.nextLine();
                                note = keyboard.nextLine();
                                System.out.println("___________________________________________");

                                break;
                            case 2:
                                break;
                        }

                    }

                    System.out.println("___________________________________________");

                    System.out.println("(1) show bill ");
                    System.out.println("(0)  Exist  ");
                    Scanner input = new Scanner(System.in);

                    choice3 = input.nextInt();
                    System.out.println("___________________________________________");

                    switch (choice3) {
                        case 1:
                            //creat varibale to save services price
                            double t;

                            //save services price to 't'
                            t = ob2.getTotal();
                            //
                            ServiceClass aggre = new ServiceClass(note);
                      //sent t 'services price' and aggre to Bill class 

                            BillClass bill = new BillClass(t, aggre);

                            //BillClass agreegation = new BillClass(ob1);
                            bill.discount();
                            
                            // Display the Bill information.

                            System.out.print(bill.toString());
                            System.out.println();
                            //
                            ob2.order();
                            System.out.println();// To print a new line
                            
                            obbill.customerprint();
                            ob1.GetName();
                            ob1.Getphone();
                            System.out.println("___________________________________________");

                            break;
                        case 0:
                            exit = false;
                            break;

                        default:
                            System.out.println("wrong enter");
                            break;
                    }
                    break;
                case 3:
                    BillClass ob3 = new BillClass(ob1);
                    /*add amount of donate
                     *donationAmount is public field in Bill class
                 
                     */
                    Scanner input2 = new Scanner(System.in);
                    System.out.println("  enter the amount of money you want to donate");

                    ob3.donationAmount = input2.nextDouble();
                    ob3.donate();
                    System.out.println("___________________________________________");

                    break;
                case 4:
                    run = false;
                    break;
            }

        } while (run);

    }
}
