
package nailspaapplication;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.Date;
import java.io.*;

public class CustomerClass {

    Scanner keyboard = new Scanner(System.in);
    private String phone, name;
    String costumers = "costumers.txt";
    private String day;
 
  String TitalLine[]={"name","phone number","date"};
  
    public CustomerClass(String a, String b) { 
    phone=a;
    name=b;
    }
  

    public String Getphone() {
        return phone;
    }

    public String GetName() {
        return name;

    }

    public void setPhone(String edit) {

        phone = edit;
    }

    public void setName(String edit) {
        name = edit;
    }

    public void addCostumer() {
        System.out.println("  Please enter your name");
        name = keyboard.nextLine();
        System.out.println("  enter your phone number");
        phone = keyboard.nextLine();

    }

    public void write() throws IOException {
              
   
        FileWriter file = new FileWriter(costumers, true);
        PrintWriter write = new PrintWriter(file);
       
        write.print(" " + name + "   " + phone);
        date();
        write.println("   " + day + "\n");
        write.close();
    }

    public void date() {

        Date when = new Date();
        day = when.toString();
    }
    public String getdate(){
    
    return day;
    }

    public void searchCostumer() throws FileNotFoundException {
        
        Scanner sc1 = new Scanner(System.in);
        
        System.out.println("Enter your name");
        String word = sc1.next();
        
        boolean flag = false;
       // System.out.println("Contents of the line");
        //Reading the contents of the file
        Scanner sc2 = new Scanner(new FileInputStream(costumers));
        while (sc2.hasNextLine()) {
            String line = sc2.nextLine();//reading line by line
            // System.out.println(line);
            if (line.contains(word)) {
                       for(int i=0;i<3;i++){
          System.out.print("  "+TitalLine[i]+" ");
                            }
        System.out.println();
   
                System.out.println(line);
                System.out.println();
                flag = true;
            }
            
        } if (!flag) {
            System.out.println("there is no one caleed by this name in our system");

        }
    }
    
    public void deleteCustomer () throws FileNotFoundException, IOException{
    
     Scanner sc1 = new Scanner(System.in);
         PrintWriter write = new PrintWriter("temp.txt");
      System.out.println("   Enter the name you want to delete");
      String word = sc1.next();
      boolean flag = false;
      //Reading the contents of the file
      Scanner sc2 = new Scanner(new FileInputStream(costumers));
      while(sc2.hasNextLine()) {
         String line = sc2.nextLine();//reading line by line
         if(!line.contains(word)) {
           
            write.println(line);
            flag = true;
        
         }        
        
    }   if (flag){
      System.out.println(" \n customer deleted ");
    }
    else{
       System.out.println(" \n  costumer is not found");
    }
         write.close();
         FileOutputStream writer = new FileOutputStream(costumers);
        writer.write(("").getBytes());
        writer.close(); 
       PrintWriter copy = new PrintWriter(costumers);
       
     File readfile=new File("temp.txt");
        // Create a Scanner object passing File object 
        Scanner reading= new Scanner(readfile);
        // Perform a priming read to read the first line of  the file 
        String line=reading.nextLine();
          copy.println(line);
        // Loop until you are at the end of the file 
        while(reading.hasNext()){
           line=reading.nextLine();
             copy.println(line);     
          }
        // Close the  file 
         reading.close();
         copy.close();
         
         FileOutputStream writertemp = new FileOutputStream("temp.txt");
        writer.write(("").getBytes());
        writertemp.close();
    
    
    
    
    
    }
    
    
    
    
    
}


