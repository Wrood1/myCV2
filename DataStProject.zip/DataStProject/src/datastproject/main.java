
package datastproject;

import java.util.Scanner;

/**
 *
 * @author w
 */
public class main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int id, choose;
        String name, First_day, phoneNumber, address;
        double salary;
        int hours;
        boolean flag = true;
        process1 employee = new process1();

        System.out.println( "\n\n                                               - Wellcome to Employee record management system - " );

        
        while(flag)  {
            
            System.out.println( "_______________________________\n " );
            System.out.println( "  - Here the menu\n " );

            System.out.println(
                    
                    " 1- Insert employee record \n"
                    + " 2- Delete employee record \n"
                    + " 3- Update employee record \n"
                    + " 4- Show employee \n"
                    + " 5- Search employee\n"
                    + " 6- Update salary \n"
                    + " 7- Exit \n");
            
            System.out.println( "Select your choice " );
            choose = input.nextInt();
            
            switch (choose) {

                case 1:// Insert employee record
                    System.out.print("Enter employee ID:");
          
              id = input.nextInt();
             input.nextLine();
             
            if (!employee.checkRecord(id)) {
      System.out.println("the Employee with id ( " + id + " ) are already exist ");
                    } //if 2
     else  {
                        
                        
        System.out.print("Enter employee Name:");
        name = input.nextLine();
       System.out.print("Enter First day of work :");
        First_day = input.nextLine();
          System.out.print("Enter Phone number :");
        phoneNumber = input.nextLine();
       System.out.print("Enter Address :");
       address = input.nextLine();
       System.out.print("Enter Work hours :");
        hours = input.nextInt();
       System.out.print("Enter Salary :");
          salary = input.nextDouble();
          
 employee.insertEmployeeInfo(id,name,First_day,phoneNumber,address,hours,salary);
     }
           
  
                     // end of insert the Record 
                   
                     
                     
                     
                     break;

                case 2: //Delete employee record

                    System.out.println("Enter the ID of the employee to delete :");
                    id = input.nextInt();
                    if (employee.deleteRecord(id) == 1) {
                        System.out.println("   done  ");

                    } else {// if return 0
                        System.out.println("Employee with " + id + " does not Exist");
                    }
                    break;

                case 3: //Update employee record
                    System.out.println("Enter the ID of the employee to Update :");
                    id = input.nextInt();
                    employee.updateEmployee(id);
                    break;

                case 4: // Show employee
                 System.out.println( "_______________________________ " );
                    employee.showRecord();
                    break;

                case 5: // Search employee
                    System.out.println("Enter the ID of the employee to Search :");
                    id = input.nextInt();
                    employee.search(id);

                    break;

                case 6: // Update salary
                    employee.UpdateSalary();
                    break;

                case 7: // Exit
                    flag = false;
                    break;

                default:
                    System.out.println("-- Wrong choice !!! --");

            }
        }

    }

}
