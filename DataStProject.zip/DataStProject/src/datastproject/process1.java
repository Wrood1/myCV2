/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastproject;

import java.util.Scanner;

/**
 *
 * @author w
 */
public class process1 {
    Node head;
    
            //*******************************  insertEmployeeInfo  **********************************************/ 

    void insertEmployeeInfo(int id, String name, String phoneNumber, String First_day, String address, int workHour, double salary) {

        Node new_node = new Node(id, name, phoneNumber, First_day, address, workHour, salary);
       if (head == null) {
            head = new_node;
            return;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        //وصل للنود الاخيره 
        //النود الاخيره اصبحت تاشر على النود الجديده
        temp.next = new_node;

    }

        //*******************************  check  **********************************************/ 
    
    
    boolean checkRecord(int id) {
        Node temp = head;
       
        while (temp != null ) {
            if (temp.id == id) {
                return false ; // id موجود 
            }
            temp = temp.next;
        }// end while
        return true; // id مو موجود وبيكمل عملية الادخال 
    }//end check

   //*******************************  search  **********************************************/ 

    public void search(int ID) {
        Node temp = head;
        while (temp != null) {
            if (temp.id == ID) {
                System.out.println("Employee Info :\n- ID:" + ID + "\n- Name:" + temp.name + "\n- First day of work: "
                        + temp.First_day + "\n- Phone number: " + temp.phoneNumber + "\n- Address :" + temp.address + "\n- Work hours: " + temp.workHour
                        + "\n- Salary: " + temp.salary);
                return;
            } else {
                temp = temp.next;
            }
        }
        System.out.println("employee with ID (" + ID + ") not registered");
    }//end search

      /*******************************  show  **********************************************/ 

        public void showRecord(){
            
          
        Node temp2=head;
        // Node current will point to head
        Node current = head, index = null;
 
        int tempID;
                String tempName;
        String tempPhoneNumber;
        String tempFirst_day;
        String tempAddress;
        int tempWorkHour;
                double tempSalary;
 
        if (head == null) {
            return;
        }
        else {
            while (current != null) {// it is not empty 
                
                // Node index will point to node next to current
                index = current.next;
 
                while (index != null) {
                    // If current node's data is greater  than index's node data, swap the data between them
                    
                    if (current.id > index.id) {
                        // 1
                        tempID = current.id;
                             tempName=current.name;
         tempPhoneNumber=current.phoneNumber;
         tempFirst_day=current.First_day;
         tempAddress=current.address;
         tempWorkHour=current.workHour;
                 tempSalary=current.salary;

                        // 2
                        current.id = index.id;
                  current.First_day = index.First_day;
                        current.address = index.address;
                              current.name = index.name;
                          current.phoneNumber = index.phoneNumber;
                                current.salary = index.salary;
                                        current.workHour = index.workHour;

                                        // 3
                        index.id = tempID;
                        index.name=tempName;
                        index.address=tempAddress;
                        index.phoneNumber=tempPhoneNumber;
                        index.First_day=tempFirst_day;
                        index.workHour=tempWorkHour;
                        index.salary=tempSalary;
      
                        
                    }// end  of  if (current.id > index.id)
 // اغير مكان الانديكس 
                    index = index.next;
                    
                }// end  while (index != null)
                current = current.next;  
            } //  while (current != null) {// it is not empty 
            
        }// end else
        
            while(temp2!=null){
        
            System.out.println("\n       Employee Info :\n- ID:" + temp2.id + "\n- Name:" + temp2.name + "\n- First day of work: "
     + temp2.First_day + "\n- Phone number: " + temp2.phoneNumber + "\n- Address :" + temp2.address + "\n- Work hours: " + temp2.workHour
         + "\n- Salary: " + temp2.salary+"\n*************************");
            temp2=temp2.next;
     }}
    
    //******************************  deleteRecord  ***********************************************/ 

    public int deleteRecord(int ID) {
         
         Node temp=head,prev=null;
         if (temp != null && temp.id == ID) {
            head = temp.next; 
            return 1;
        }
         while (temp != null && temp.id != ID) {
            prev = temp;
            temp = temp.next;
        }
        if(temp==null){
            return 0;
        }
        prev.next=temp.next;  // if it found 
        return 1;
   
    }//end of delete

    
    
    /****************************** update a Salary ***********************************************/ 
    
    
    
    public void UpdateSalary() {

        if (head == null) {
            return;
        }
        Node temp = head;
       while(temp!=null){
            if(temp.workHour>32){
                temp.salary+=(temp.salary*.02);
            
            }
            temp=temp.next;
        }
        System.out.println(" - Finsh updated -");
    }     //end  update a Salary

    

        //*************** updateEmployee  ***********************************************

    
    
     public void updateEmployee(int id){
         if(checkRecord(id)){
             System.out.println(" - Employee not found - ");
         }else{
             Scanner input=new Scanner(System.in);
             String name,day,phone_mumber,address;
             int hours;
             double salary;
                        System.out.print("Enter the new employee's name:");  
                        name=input.nextLine();
                        System.out.print("Enter the new First day of work, please.:");  
                        day=input.nextLine();
                        System.out.print("Enter the new Phone number:");  
                        phone_mumber=input.nextLine();
                        System.out.print("Enter the new Address:");  
                        address=input.nextLine();
                        System.out.print("Enter the new Work hours:");  
                        hours=input.nextInt();
                        System.out.print("Enter the new Salary:");  
                        salary=input.nextDouble();
                        
              Node temp=head;
                while(temp!=null){
                    if(temp.id==id){
                          temp.name=name;
                          temp.salary=salary;
                          temp.address=address;
                          temp.First_day=day;
                          temp.workHour=hours;
                          temp.phoneNumber=phone_mumber;
                    }
                    temp=temp.next;
                }
         }
           
         
     }
        
        


   
}
    
    
    
    


    
    
    
    
    
    
    
    
    
    

