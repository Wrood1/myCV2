/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastproject;

/**
 *
 * @author w
 */
public class Node {

    Node next;
    int id;
    String name, phoneNumber, First_day, address;
    int workHour;
    double salary;

    public Node(int id, String name, String phoneNumber, String First_day, String address, int workHour, double salary) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.First_day = First_day;
        this.address = address;
        this.workHour = workHour;
        this.salary = salary;
        this.next = null;
    }

    Node(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  

}
