/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastproject;

/**
 *
 * @author w
 */
public class RecordProcess {
    
    Node head=null;
    

    public RecordProcess() {
    }  
    void insertEmployeeInfo(int id, String name, String phoneNumber, String First_day, String address, int workHour, double salary){
        // create new  employee record
        Node newNode =new Node(id,name,  phoneNumber,  First_day,  address,  workHour,  salary);
        //if is empty
       if (head == null) {
           head=newNode;
        }
        else{
           Node temp=head;
        while(temp.next!=null){
            temp=temp.next;
        }//وصل للنود الاخيره 
        //النود الاخيره اصبحت تاشر على النود الجديده
        temp.next=newNode;
        temp=newNode;
        
    }
    }// end of insert method
    
void CheckID(int id){
    
    Node temp2=head;
    boolean flag=true;
    
    while(flag){
        if (temp2.id!=id&&temp2.next!=null)
        temp2=temp2.next;
        
        else if(temp2.id==id){
    System.out.print("error - The Employee with ID "+id+ " are already exist -");}
    flag=false;
}
}//end while 
//end check 
  public void display()
    {
        // Node current will point to head
        Node current = head;
 
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        while (current != null) {
            // Prints each node by incrementing pointer
            System.out.print(current.id + " ");
            current = current.next;
        }
 
        System.out.println();
    }
}